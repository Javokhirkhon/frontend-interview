import "./App.css";
import Applications from "./Applications";
import Header from "./Header";

function App() {
  return (
    <div className="App">
      <Header />
      <Applications />
    </div>
  );
}

export default App;
