export const getSingleApplicationFixture = [
  {
    guid: "8a8f6cbc-77a1-4086-8968-a57816f4ff60",
    loan_amount: 37597,
    first_name: "Miles",
    last_name: "Espinoza",
    company: "Qnekt",
    email: "milesespinoza@qnekt.com",
    date_created: "2021-08-10",
    expiry_date: "2021-12-02",
  },
];
